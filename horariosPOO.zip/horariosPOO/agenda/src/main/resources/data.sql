insert into professores(nome_Professor) values ('Ana Beatriz Almeida');
insert into professores(nome_Professor) values ('Carlos Eduardo Silva');
insert into professores(nome_Professor) values ('Gustavo Souza');
insert into professores(nome_Professor) values ('Fernanda Oliveira');

insert into horarios(hora_Inicio, hora_Fim) values ('18:55','19:40');
insert into horarios(hora_Inicio, hora_Fim) values ('19:45','20:35');
insert into horarios(hora_Inicio, hora_Fim) values ('20:50','21:40');
insert into horarios(hora_Inicio, hora_Fim) values ('21:40','22:30');

insert into cursos(nome_Curso) values ('Engenharia de Software');
insert into cursos(nome_Curso) values ('Sistemas de Informação');
insert into cursos(nome_Curso) values ('Engenharia da Computação');
insert into cursos(nome_Curso) values ('Analise e Desenvolvimento Web');

insert into salas(nome_Sala) values ('C318-C320');
insert into salas(nome_Sala) values ('C316');
insert into salas(nome_Sala) values ('C315');
insert into salas(nome_Sala) values ('314');
insert into salas(nome_Sala) values ('C325-C327');

insert into turmas(nome_Turma, nome_Curso_id, semestre) values ('144-1AN',1,1);
insert into turmas(nome_Turma, nome_Curso_id, semestre) values ('144-1BN',1,2);
insert into turmas(nome_Turma, nome_Curso_id, semestre) values ('145-1AN',2,1);
insert into turmas(nome_Turma, nome_Curso_id, semestre) values ('145-2BN',2,2);
insert into turmas(nome_Turma, nome_Curso_id, semestre) values ('146-1AN',3,1);
insert into turmas(nome_Turma, nome_Curso_id, semestre) values ('146-1BN',3,2);
insert into turmas(nome_Turma, nome_Curso_id, semestre) values ('147-1AN',4,1);
insert into turmas(nome_Turma, nome_Curso_id, semestre) values ('147-1BN',4,2);

insert into materias(nome_Materia, nome_Professor_id) values ('Programação Orientada à Objetos', 1);
insert into materias(nome_Materia, nome_Professor_id) values ('Programação Orientada à ',2);
insert into materias(nome_Materia, nome_Professor_id) values ('Programação Orientada ',3);
insert into materias(nome_Materia, nome_Professor_id) values ('Programação',4);


insert into planos( codigo, nome_Sala_id, aula_aula, nome_Materia_id, nome_Turma_id) values ('AB1BAWPO', 1, 1, 1, 8);
insert into planos( codigo, nome_Sala_id, aula_aula, nome_Materia_id, nome_Turma_id) values ('CE1AECDW', 2, 2, 2, 5);
insert into planos( codigo, nome_Sala_id, aula_aula, nome_Materia_id, nome_Turma_id) values ('GS1ASIBD', 5, 1, 3, 3);
insert into planos( codigo, nome_Sala_id, aula_aula, nome_Materia_id, nome_Turma_id) values ('FO1BESSO', 4, 2, 4, 2);

/*
insert into datas(data ) values ('Programação Orientada a Objetos');
insert into datas(data ) values (2,'Desenvolvimento Web');
insert into datas(data ) values (3,'Banco de Dados');
insert into datas(data ) values (4,'Sistemas Operacionais');
*/

