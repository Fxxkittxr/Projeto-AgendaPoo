package com.leandersonandre.agenda.core.service;

import com.leandersonandre.agenda.core.entity.Professores;
import com.leandersonandre.agenda.core.repository.ProfessoresRepository;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProfessoresServico {

    @Autowired
    ProfessoresRepository professoresRepository;

    public List<Professores> obterTodos() {
        return professoresRepository.findAll();
    }

    public Optional<Professores> obterPeloId(long id) {
        return professoresRepository.findById(id);
    }

    public void salvar(Professores professores) {
        if(Strings.isBlank(professores.getNomeProfessor())){
            throw new RuntimeException("Favor informar o nome");
        }
        professoresRepository.save(professores);
    }
}
