package com.leandersonandre.agenda.core.service;

import com.leandersonandre.agenda.core.entity.Planos;
import com.leandersonandre.agenda.core.repository.PlanosRepository;
import com.leandersonandre.agenda.core.entity.Salas;
import com.leandersonandre.agenda.core.repository.SalasRepository;
import com.leandersonandre.agenda.core.entity.Horarios;
import com.leandersonandre.agenda.core.repository.HorariosRepository;
import com.leandersonandre.agenda.core.entity.Materias;
import com.leandersonandre.agenda.core.repository.MateriasRepository;
import com.leandersonandre.agenda.core.entity.Turmas;
import com.leandersonandre.agenda.core.repository.TurmasRepository;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PlanosServico {

    @Autowired
    PlanosRepository planosRepository;

    @Autowired
    SalasRepository salasRepository; // Injete o repositório de Salas

    @Autowired
    HorariosRepository horariosRepository; // Injete o repositório de Horarios

    @Autowired
    MateriasRepository materiasRepository; // Injete o repositório de Materias

    @Autowired
    TurmasRepository turmasRepository; // Injete o repositório de Turmas

    public List<Planos> obterTodos() {
        return planosRepository.findAll();
    }

    public Optional<Planos> obterPeloId(long id) {
        return planosRepository.findById(id);
    }

    public void salvar(Planos Planos) {
        if(Strings.isBlank(Planos.getCodigo())){
            throw new RuntimeException("Favor informar o nome");
        }

        if(Planos.getNomeSala() == null) {
            throw new RuntimeException("Favor selecionar uma sala");
        }

        if(Planos.getAula() == null) {
            throw new RuntimeException("Favor selecionar um horario");
        }

        if(Planos.getNomeMateria() == null) {
            throw new RuntimeException("Favor selecionar uma matéria");
        }

        if(Planos.getNomeTurma() == null) {
            throw new RuntimeException("Favor selecionar uma turma");
        }

        planosRepository.save(Planos);
    }

    public List<Salas> obterTodasSalas() {
        return salasRepository.findAll();
    }

    public List<Horarios> obterTodosHorarios() {
        return horariosRepository.findAll();
    }
    
    public List<Materias> obterTodasMaterias() {
        return materiasRepository.findAll();
    }

    public List<Turmas> obterTodasTurmas() {
        return turmasRepository.findAll();
    }

}

