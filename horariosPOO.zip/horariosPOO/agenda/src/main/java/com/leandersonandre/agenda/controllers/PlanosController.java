package com.leandersonandre.agenda.controllers;

import com.leandersonandre.agenda.core.entity.Planos;
import com.leandersonandre.agenda.core.entity.Salas;
import com.leandersonandre.agenda.core.entity.Horarios;
import com.leandersonandre.agenda.core.entity.Materias;
import com.leandersonandre.agenda.core.entity.Turmas;
import com.leandersonandre.agenda.core.service.PlanosServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/planos")
public class PlanosController {

    @Autowired
    PlanosServico planosServico;

    @GetMapping
    public ModelAndView index(){
        List<Planos> planos = planosServico.obterTodos();

        // Agrupa as planos por turma
        Map<Turmas, List<Planos>> planosPorTurma = planos.stream()
        .collect(Collectors.groupingBy(Planos::getNomeTurma));
        ModelAndView view = new ModelAndView("planos/planos.html");
        view.addObject("planosPorTurma", planosPorTurma);

        return view;
    }


    @GetMapping("/{id}/editar")
    public ModelAndView editar(@PathVariable("id") long id){
        ModelAndView view = new ModelAndView("planos/planos_edit.html");
        var opt = planosServico.obterPeloId(id);
        opt.ifPresent(entidade -> view.addObject("entidade", entidade));
        
        List<Salas> salas = planosServico.obterTodasSalas(); 
        view.addObject("salas", salas);

        List<Horarios> horarios = planosServico.obterTodosHorarios(); 
        view.addObject("horarios", horarios);

        List<Materias> materias = planosServico.obterTodasMaterias(); 
        view.addObject("materias", materias);

        List<Turmas> turmas = planosServico.obterTodasTurmas(); 
        view.addObject("turmas", turmas);

        return view;
    }

    @GetMapping("/criar")
    public ModelAndView criarNovoPlanos(){
        ModelAndView view = new ModelAndView("planos/planos_add.html");
        view.addObject("entidade", new Planos());

        List<Salas> salas = planosServico.obterTodasSalas(); 
        view.addObject("salas", salas);

        List<Horarios> horarios = planosServico.obterTodosHorarios(); 
        view.addObject("horarios", horarios);

        List<Materias> materias = planosServico.obterTodasMaterias(); 
        view.addObject("materias", materias);

        List<Turmas> turmas = planosServico.obterTodasTurmas(); 
        view.addObject("turmas", turmas);
        
        return view;
    }

    @PostMapping("/atualizar")
    public ModelAndView salvar(@ModelAttribute("entidade") Planos planos){
        try {
            planosServico.salvar(planos);
            return new ModelAndView("redirect:/planos");
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("planos/planos_edit.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", planos);
            return model;
        }
    }

    @PostMapping("/criar")
    public ModelAndView criar(@ModelAttribute("entidade") Planos planos){
        try {
            planosServico.salvar(planos);
            return new ModelAndView("redirect:/planos");
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("planos/planos_add.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", planos);
            return model;
        }
    }
}
