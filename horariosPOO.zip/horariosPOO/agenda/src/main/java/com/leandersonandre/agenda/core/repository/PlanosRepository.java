package com.leandersonandre.agenda.core.repository;

import com.leandersonandre.agenda.core.entity.Planos;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlanosRepository extends JpaRepository<Planos, Long>{
}
