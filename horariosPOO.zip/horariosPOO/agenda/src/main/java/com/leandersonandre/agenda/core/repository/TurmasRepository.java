package com.leandersonandre.agenda.core.repository;

import com.leandersonandre.agenda.core.entity.Turmas;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TurmasRepository extends JpaRepository<Turmas, Long>{
}
