package com.leandersonandre.agenda.core.repository;

import com.leandersonandre.agenda.core.entity.Cursos;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CursosRepository extends JpaRepository<Cursos, Long>{
}
