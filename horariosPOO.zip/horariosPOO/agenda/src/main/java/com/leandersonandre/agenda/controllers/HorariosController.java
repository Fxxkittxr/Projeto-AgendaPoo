package com.leandersonandre.agenda.controllers;

import com.leandersonandre.agenda.core.entity.Horarios;
import com.leandersonandre.agenda.core.service.HorariosServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/horarios")
public class HorariosController {

    @Autowired
    HorariosServico horariosServico;

    @GetMapping
    public ModelAndView index(){
        ModelAndView view = new ModelAndView("horarios/horarios");
        view.addObject("horarios", horariosServico.obterTodos());
        return view;
    }

    @GetMapping("/{aula}/editar")
    public ModelAndView editar(@PathVariable("aula") long aula){
        ModelAndView view = new ModelAndView("horarios/horarios_edit");
        var opt = horariosServico.obterPeloId(aula);
        opt.ifPresent(entidade -> view.addObject("entidade", entidade));
        return view;
    }

    @GetMapping("/criar")
    public ModelAndView criarNovoHorarios(){
        ModelAndView view = new ModelAndView("horarios/horarios_add");
        view.addObject("entidade", new Horarios());
        return view;
    }

    @PostMapping("/atualizar")
    public ModelAndView salvar(@ModelAttribute("entidade") Horarios horarios){
        try {
            horariosServico.salvar(horarios);
            return new ModelAndView("redirect:/horarios");
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("horarios/horarios_edit");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", horarios);
            return model;
        }
    }

    @PostMapping("/criar")
    public ModelAndView criar(@ModelAttribute("entidade") Horarios horarios){
        try {
            System.out.println(horarios);
            horarios.setAula(0);
            horariosServico.salvar(horarios);
            return new ModelAndView("redirect:/horarios");
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("horarios/horarios.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", horarios);
            return model;
        }
    }

}
