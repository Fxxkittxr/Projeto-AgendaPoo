package com.leandersonandre.agenda.controllers;

import com.leandersonandre.agenda.core.entity.Professores;
import com.leandersonandre.agenda.core.service.ProfessoresServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/professores")
public class ProfessoresController {

    @Autowired
    ProfessoresServico professoresServico;

    @GetMapping
    public ModelAndView index(){
        ModelAndView view = new ModelAndView("professores/professores.html");
        view.addObject("professores", professoresServico.obterTodos());
        return view;
    }

    @GetMapping("/{id}/editar")
    public ModelAndView editar(@PathVariable("id") long id){
        ModelAndView view = new ModelAndView("professores/professores_edit.html");
        var opt = professoresServico.obterPeloId(id);
        opt.ifPresent(entidade -> view.addObject("entidade", entidade));
        return view;
    }

    @GetMapping("/criar")
    public ModelAndView criarNovoProfessores(){
        ModelAndView view = new ModelAndView("professores/professores_add.html");
        view.addObject("entidade", new Professores());
        return view;
    }

    @PostMapping("/atualizar")
    public ModelAndView salvar(@ModelAttribute("entidade") Professores professores){
        try {
            professoresServico.salvar(professores);
            return new ModelAndView("redirect:/professores");
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("professores/professores_edit.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", professores);
            return model;
        }
    }

    @PostMapping("/criar")
    public ModelAndView criar(@ModelAttribute("entidade") Professores professores){
        try {
            professoresServico.salvar(professores);
            return new ModelAndView("redirect:/professores");
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("professores/professores_add.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", professores);
            return model;
        }
    }
}
