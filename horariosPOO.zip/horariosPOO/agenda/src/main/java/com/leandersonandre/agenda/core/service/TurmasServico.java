package com.leandersonandre.agenda.core.service;

import com.leandersonandre.agenda.core.entity.Turmas;
import com.leandersonandre.agenda.core.entity.Cursos;
import com.leandersonandre.agenda.core.repository.TurmasRepository;
import com.leandersonandre.agenda.core.repository.CursosRepository;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TurmasServico {

    @Autowired
    TurmasRepository turmasRepository;

    @Autowired
    CursosRepository cursosRepository; // Injete o repositório do Curso

    public List<Turmas> obterTodos() {
        return turmasRepository.findAll();
    }

    public Optional<Turmas> obterPeloId(long id) {
        return turmasRepository.findById(id);
    }

    public void salvar(Turmas Turmas) {
        if(Strings.isBlank(Turmas.getNomeTurma())){
            throw new RuntimeException("Favor informar o nome");
        }

        if(Turmas.getNomeCurso() == null) {
            throw new RuntimeException("Favor selecionar um curso");
        }

        turmasRepository.save(Turmas);
    }

    public List<Cursos> obterTodosCursos() {
        return cursosRepository.findAll();
    }
}
