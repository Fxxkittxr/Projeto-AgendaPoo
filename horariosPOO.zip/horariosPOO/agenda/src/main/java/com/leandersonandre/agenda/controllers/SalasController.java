package com.leandersonandre.agenda.controllers;

import com.leandersonandre.agenda.core.entity.Salas;
import com.leandersonandre.agenda.core.service.SalasServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/salas")
public class SalasController {

    @Autowired
    SalasServico salasServico;

    @GetMapping
    public ModelAndView index(){
        ModelAndView view = new ModelAndView("salas/salas.html");
        view.addObject("salas", salasServico.obterTodos());
        return view;
    }

    @GetMapping("/{id}/editar")
    public ModelAndView editar(@PathVariable("id") long id){
        ModelAndView view = new ModelAndView("salas/salas_edit.html");
        var opt = salasServico.obterPeloId(id);
        opt.ifPresent(entidade -> view.addObject("entidade", entidade));
        return view;
    }

    @GetMapping("/criar")
    public ModelAndView criarNovaSalas(){
        ModelAndView view = new ModelAndView("salas/salas_add.html");
        view.addObject("entidade", new Salas());
        return view;
    }

    @PostMapping("/atualizar")
    public ModelAndView salvar(@ModelAttribute("entidade") Salas salas){
        try {
            salasServico.salvar(salas);
            return new ModelAndView("redirect:/salas");
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("salas/salas_edit.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", salas);
            return model;
        }
    }

    @PostMapping("/criar")
    public ModelAndView criar(@ModelAttribute("entidade") Salas salas){
        try {
            salasServico.salvar(salas);
            return new ModelAndView("redirect:/salas");
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("salas/salas_add.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", salas);
            return model;
        }
    }
}
