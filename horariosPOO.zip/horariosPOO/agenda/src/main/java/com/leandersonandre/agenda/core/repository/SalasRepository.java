package com.leandersonandre.agenda.core.repository;

import com.leandersonandre.agenda.core.entity.Salas;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalasRepository extends JpaRepository<Salas, Long>{
}
