package com.leandersonandre.agenda.core.repository;

import com.leandersonandre.agenda.core.entity.Horarios;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HorariosRepository extends JpaRepository<Horarios, Long>{
}
