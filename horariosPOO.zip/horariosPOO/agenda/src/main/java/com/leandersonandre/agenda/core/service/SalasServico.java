package com.leandersonandre.agenda.core.service;

import com.leandersonandre.agenda.core.entity.Salas;
import com.leandersonandre.agenda.core.repository.SalasRepository;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SalasServico {

    @Autowired
    SalasRepository salasRepository;

    public List<Salas> obterTodos() {
        return salasRepository.findAll();
    }

    public Optional<Salas> obterPeloId(long id) {
        return salasRepository.findById(id);
    }

    public void salvar(Salas Salas) {
        if(Strings.isBlank(Salas.getNomeSala())){
            throw new RuntimeException("Favor informar o nome da sala");
        }
        salasRepository.save(Salas);
    }
}
