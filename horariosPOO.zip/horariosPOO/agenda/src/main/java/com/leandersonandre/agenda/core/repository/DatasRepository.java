package com.leandersonandre.agenda.core.repository;

import com.leandersonandre.agenda.core.entity.Datas;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DatasRepository extends JpaRepository<Datas, Long>{
}
