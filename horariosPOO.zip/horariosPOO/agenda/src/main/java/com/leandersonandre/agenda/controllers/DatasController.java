package com.leandersonandre.agenda.controllers;

import com.leandersonandre.agenda.core.entity.Datas;
import com.leandersonandre.agenda.core.service.DatasServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/data")
public class DatasController {

    @Autowired
    DatasServico datasServico;

    @GetMapping
    public ModelAndView index(){
        ModelAndView view = new ModelAndView("datas/data.html");
        view.addObject("datas", datasServico.obterTodos());
        return view;
    }

    @GetMapping("/{id}")
    public ModelAndView visualizar(@PathVariable("id") long id){
        ModelAndView view = new ModelAndView("datas/datas_view.html");
        var opt = datasServico.obterPeloId(id);
        opt.ifPresent(entidade -> view.addObject("entidade", entidade));
        return view;
    }

    @GetMapping("/{id}/editar")
    public ModelAndView editar(@PathVariable("id") long id){
        ModelAndView view = new ModelAndView("datas/editar.html");
        var opt = datasServico.obterPeloId(id);
        opt.ifPresent(entidade -> view.addObject("entidade", entidade));
        return view;
    }

    @GetMapping("/criar")
    public ModelAndView criarNovoData(){
        ModelAndView view = new ModelAndView("datas/criar.html");
        view.addObject("entidade", new Datas());
        return view;
    }

    @PostMapping("/atualizar")
    public ModelAndView salvar(@ModelAttribute("entidade") Datas datas){
        try {
            datasServico.salvar(datas);
            return new ModelAndView("redirect:/datas/" + datas.getId());
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("datas/editar.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", datas);
            return model;
        }
    }

    @PostMapping("/criar")
    public ModelAndView criar(@ModelAttribute("entidade") Datas datas){
        try {
            System.out.println(datas);
            datas.setId(0);
            datasServico.salvar(datas);
            return new ModelAndView("redirect:/datas/" + datas.getId());
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("datas/criar.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", datas);
            return model;
        }
    }

}
