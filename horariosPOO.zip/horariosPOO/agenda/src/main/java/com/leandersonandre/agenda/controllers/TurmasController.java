package com.leandersonandre.agenda.controllers;

import com.leandersonandre.agenda.core.entity.Cursos;
import com.leandersonandre.agenda.core.entity.Turmas;
import com.leandersonandre.agenda.core.service.TurmasServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/turmas")
public class TurmasController {

    @Autowired
    private TurmasServico turmasServico;

    @GetMapping
    public ModelAndView index() {
        List<Turmas> turmas = turmasServico.obterTodos();

        // Agrupa as turmas por semestre
        Map<Long, List<Turmas>> turmasPorSemestre = turmas.stream()
            .collect(Collectors.groupingBy(Turmas::getSemestre));

        ModelAndView view = new ModelAndView("turmas/turmas");
        view.addObject("turmasPorSemestre", turmasPorSemestre);
        return view;
    }

    @GetMapping("/{id}/editar")                                                                                                                                
    public ModelAndView editar(@PathVariable("id") long id){
        ModelAndView view = new ModelAndView("turmas/turmas_edit");
        var opt = turmasServico.obterPeloId(id);
        opt.ifPresent(entidade -> view.addObject("entidade", entidade));
        List<Cursos> cursos = turmasServico.obterTodosCursos(); 
        view.addObject("cursos", cursos); 
        return view;
    }

    @GetMapping("/criar")
    public ModelAndView criarNovaTurma() {
        ModelAndView view = new ModelAndView("turmas/turmas_add");
        view.addObject("entidade", new Turmas());
        List<Cursos> cursos = turmasServico.obterTodosCursos();
        view.addObject("cursos", cursos);
        return view;
    }

    @PostMapping("/atualizar")
    public ModelAndView salvar(@ModelAttribute("entidade") Turmas turmas) {
        try {
            turmasServico.salvar(turmas);
            return new ModelAndView("redirect:/turmas");
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("turmas/turmas_edit");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", turmas);
            return model;
        }
    }

    @PostMapping("/criar")
    public ModelAndView criar(@ModelAttribute("entidade") Turmas turmas) {
        try {
            turmasServico.salvar(turmas);
            return new ModelAndView("redirect:/turmas");
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("turmas/turmas_add");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", turmas);
            return model;
        }
    }
}
