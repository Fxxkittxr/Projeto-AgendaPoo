
package com.leandersonandre.agenda.controllers;

import com.leandersonandre.agenda.core.entity.Cursos;
import com.leandersonandre.agenda.core.service.CursosServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/cursos")
public class CursosController {

    @Autowired
    CursosServico cursosServico;


    @GetMapping
    public ModelAndView index() {
        ModelAndView view = new ModelAndView("cursos/cursos.html");
        view.addObject("cursos", cursosServico.obterTodos());
        return view;
    }

    @GetMapping("/{id}/editar")
    public ModelAndView editar(@PathVariable("id") long id) { 
        ModelAndView view = new ModelAndView("cursos/cursos_edit");
        var opt = cursosServico.obterPeloId(id);
        opt.ifPresent(entidade -> view.addObject("entidade", entidade));
        return view;
    }

    @GetMapping("/criar")
    public ModelAndView criarNovoCurso() {
        ModelAndView view = new ModelAndView("cursos/cursos_add.html");
        view.addObject("entidade", new Cursos());
        return view;
    }

    @PostMapping("/atualizar")
    public ModelAndView salvar(@ModelAttribute("entidade") Cursos cursos) {
        try {
            cursosServico.salvar(cursos);
            return new ModelAndView("redirect:/cursos" );
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("cursos/cursos_edit.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", cursos);
            return model;
        }
    }

    @PostMapping("/criar")
    public ModelAndView criar(@ModelAttribute("entidade") Cursos cursos) {
        try { 
            cursosServico.salvar(cursos);
            return new ModelAndView("redirect:/cursos");
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("cursos/cursos_add.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", cursos);
            return model;
        }
    }
}
