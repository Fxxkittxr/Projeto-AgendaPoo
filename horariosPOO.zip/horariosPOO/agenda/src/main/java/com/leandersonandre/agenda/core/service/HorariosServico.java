package com.leandersonandre.agenda.core.service;

import com.leandersonandre.agenda.core.entity.Horarios;
import com.leandersonandre.agenda.core.repository.HorariosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HorariosServico {

    @Autowired
    HorariosRepository horariosRepository;

    public List<Horarios> obterTodos() {
        var lista = horariosRepository.findAll();
        System.out.println(lista.size());
        return lista;
    }

    public Optional<Horarios> obterPeloId(long aula) {
        return horariosRepository.findById(aula);
    }

    public void salvar(Horarios Horarios) {
        // if(Strings.isBlank(Horarios.getHoraInicio())){
        //     throw new RuntimeException("Favor informar a hora de inicio");
        // }
        // if(Strings.isBlank(Horarios.getHoraFim())){
        //     throw new RuntimeException("Favor informar a hora de inicio");
        // }
        horariosRepository.save(Horarios);
    }
}

/*

 */
