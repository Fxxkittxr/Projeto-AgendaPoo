package com.leandersonandre.agenda.core.service;

import com.leandersonandre.agenda.core.entity.Cursos;
import com.leandersonandre.agenda.core.repository.CursosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CursosServico {

    @Autowired
    CursosRepository cursosRepository;

    public List<Cursos> obterTodos() {
        var lista = cursosRepository.findAll();
        System.out.println(lista.size());
        return lista;
    }

    public Optional<Cursos> obterPeloId(long id) {
        return cursosRepository.findById(id);
    }

    public void salvar(Cursos Cursos) {
        // if(Strings.isBlank(Cursos.getNomeCurso())){
        //     throw new RuntimeException("Favor informar o nome do curso");
        // }
        cursosRepository.save(Cursos);
    }
}

/*

 */
