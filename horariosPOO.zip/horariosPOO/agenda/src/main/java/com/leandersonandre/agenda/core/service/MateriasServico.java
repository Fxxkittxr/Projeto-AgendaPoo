package com.leandersonandre.agenda.core.service;

import com.leandersonandre.agenda.core.entity.Materias;
import com.leandersonandre.agenda.core.entity.Professores;
import com.leandersonandre.agenda.core.repository.MateriasRepository;
import com.leandersonandre.agenda.core.repository.ProfessoresRepository;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MateriasServico {

    @Autowired
    private MateriasRepository materiasRepository;

    @Autowired
    private ProfessoresRepository professoresRepository; // Injete o repositório do Professor

    public List<Materias> obterTodos() {
        return materiasRepository.findAll();
    }

    public Optional<Materias> obterPeloId(long id) {
        return materiasRepository.findById(id);
    }

    public void salvar(Materias materia) {
        if(Strings.isBlank(materia.getNomeMateria())){
            throw new RuntimeException("Favor informar o nome");
        }

        if(materia.getNomeProfessor() == null) {
            throw new RuntimeException("Favor selecionar um professor");
        }

        materiasRepository.save(materia);
    }

    public List<Professores> obterTodosProfessores() {
        return professoresRepository.findAll();
    }
}
