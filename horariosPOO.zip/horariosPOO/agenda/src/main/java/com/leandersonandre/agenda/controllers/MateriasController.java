package com.leandersonandre.agenda.controllers;

import com.leandersonandre.agenda.core.entity.Materias;
import com.leandersonandre.agenda.core.entity.Professores;
import com.leandersonandre.agenda.core.service.MateriasServico;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/materias")
public class MateriasController {

    @Autowired
    MateriasServico materiasServico;

    @GetMapping
    public ModelAndView index() {
        ModelAndView view = new ModelAndView("materias/materias.html");
        view.addObject("materias", materiasServico.obterTodos());
        return view;
    }

    @GetMapping("/{id}/editar")
    public ModelAndView editar(@PathVariable("id") long id) {
        ModelAndView view = new ModelAndView("materias/materias_edit");
        var opt = materiasServico.obterPeloId(id);
        opt.ifPresent(entidade -> view.addObject("entidade", entidade));
        List<Professores> professores = materiasServico.obterTodosProfessores(); 
        view.addObject("professores", professores); 
        return view;
    }

    @GetMapping("/criar")
    public ModelAndView criarNovaMaterias(){
        ModelAndView view = new ModelAndView("materias/materias_add.html");
        view.addObject("entidade", new Materias());
        List<Professores> professores = materiasServico.obterTodosProfessores(); 
        view.addObject("professores", professores); 
        return view;
    }

    @PostMapping("/atualizar")
    public ModelAndView salvar(@ModelAttribute("entidade") Materias materias) {
        try {
            materiasServico.salvar(materias);
            return new ModelAndView("redirect:/materias");
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("materias/materias_edit");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", materias);
            return model;
        }
    }

    @PostMapping("/criar")
    public ModelAndView criar(@ModelAttribute("entidade") Materias materias) {
        try {
            materiasServico.salvar(materias);
            return new ModelAndView("redirect:/materias");
        } catch (Exception e) {
            ModelAndView model = new ModelAndView("materias/materias_add.html");
            model.addObject("erro", e.getMessage());
            model.addObject("entidade", materias);
            return model;
        }
    }
}
