package com.leandersonandre.agenda.core.service;

import com.leandersonandre.agenda.core.entity.Datas;
import com.leandersonandre.agenda.core.repository.DatasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DatasServico {

    @Autowired
    DatasRepository datasRepository;

    public List<Datas> obterTodos() {
        return datasRepository.findAll();
    }

    public Optional<Datas> obterPeloId(long aula) {
        return datasRepository.findById(aula);
    }

    public void salvar(Datas datas) {
        datasRepository.save(datas);
    }
}